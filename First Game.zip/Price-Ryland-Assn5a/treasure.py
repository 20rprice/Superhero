# Ryland Price
# CS1400 - MWF 8:30
import pygame
import random


class Treasure:
    pass


def make_treasure(image_file):
    treasure = Treasure()
    treasure.image = pygame.image.load(image_file)
    treasure.width = treasure.image.get_width()
    treasure.height = treasure.image.get_height()
    treasure.center_position = [random.randint(treasure.width // 2, 600 - treasure.width // 2), random.randint(treasure.height // 2, 600 - treasure.height // 2)]
    treasure.draw_position = [treasure.center_position[0] - treasure.width // 2, treasure.center_position[1] - treasure.height // 2]
    treasure.radius = treasure.width // 2

    return treasure


