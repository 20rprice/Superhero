import pygame
from player import make_player, move_player
from treasure import make_treasure
from enemy import make_enemy, move_enemy


SCREEN_WIDTH = 600  # Use constants here to be able to use in different places
SCREEN_HEIGHT = 600
CLOCK_TICK = 30
TITLE = "Treasure Hunt"


def main():
    # Setup the pygame window and clock
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(TITLE)
    clock = pygame.time.Clock()

    ##########
    # Set up game media images, sounds
    background = pygame.image.load("marble.png")
    player_image = "ninja.png"
    treasure_image = "coin.png"
    enemy_image = "fireball.png"
    treasure_sound = pygame.mixer.Sound("ding.mp3")
    treasure_sound.set_volume(.5)
    enemy_sound = pygame.mixer.Sound("fire_whoosh.mp3")
    enemy_sound.set_volume(.5)
    win = pygame.mixer.Sound("win.mp3")
    win.set_volume(.5)
    pygame.mixer.music.load("dreams.mp3")
    pygame.mixer.music.set_volume(.2)
    pygame.mixer.music.play(-1)
    ##########

    ##########
    # Set up game data
    player = make_player(player_image)
    enemy = make_enemy(enemy_image)

    treasure_list = []
    treasure_number = 10
    for i in range(treasure_number):
        treasure = make_treasure(treasure_image)
        treasure_list.append(treasure)

    move = 5
    enemy_move = [15, 8]
    ##########

    ##########
    # Game Loop
    ##########
    game_over = False
    running = True
    while running:
        ##########
        # Get Input/Events
        move_player(player, move)
        move_enemy(enemy, enemy_move)

        def did_touch(player, item):
            if ((player.center_position[0] - item.center_position[0]) ** 2 + (player.center_position[1] - item.center_position[1]) ** 2) ** .5 < player.radius + item.radius:
                return True
            else:
                return False

        ##########
        #### Always Update ####
        ##########
        # Update state of components/data
        ##########

        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # User clicked the window's X button
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and game_over:
                    ### Do Stuff to Reset Game ###
                    pygame.mixer.music.load("dreams.mp3")
                    pygame.mixer.music.set_volume(.2)
                    pygame.mixer.music.play(-1)

                    player = make_player(player_image)
                    enemy = make_enemy(enemy_image)
                    enemy_move = [15, 8]

                    treasure_list = []
                    for i in range(treasure_number):
                        treasure = make_treasure(treasure_image)
                        treasure_list.append(treasure)
                    game_over = False


        #### Update if Game is Not Over ####
        if game_over:
            ### In this block of code game_over = True will happen ###
            pass

        #### Update if Game is Over ####
        else:
            temp_list = []
            for i in treasure_list:
                if not did_touch(player, i):
                    temp_list.append(i)
                else:
                    pygame.mixer.Sound.play(treasure_sound)
            treasure_list = temp_list

            if did_touch(player, enemy):
                game_over = True
                pygame.mixer.Sound.play(enemy_sound)
                pygame.mixer.music.stop()

            if len(treasure_list) == 0:
                pygame.mixer.Sound.play(win)


        ##########
        # Update Display
        ##########
        #### Always Display ####
        #### Display while Game is being played ####
        if len(treasure_list) == 0:
            game_over = True
        screen.blit(background, [0, 0])

        if not game_over:
            for i in treasure_list:
                screen.blit(i.image, i.draw_position)

            screen.blit(enemy.image, enemy.draw_position)
            screen.blit(player.image, player.draw_position)

        #### Display while Game is Over ####
        else:
            for i in treasure_list:
                screen.blit(i.image, i.draw_position)

            screen.blit(enemy.image, enemy.draw_position)
            screen.blit(player.image, player.draw_position)

            if len(treasure_list) == 0:
                text_font = pygame.font.SysFont("timesnewroman", 100).render("You Won!", True, "Green")
                screen.blit(text_font, [SCREEN_WIDTH // 2 - text_font.get_width() //2, SCREEN_HEIGHT // 2 - text_font.get_height() // 2])
            else:
                text_font = pygame.font.SysFont("timesnewroman", 100).render("Game Over", True, "Red")
                screen.blit(text_font, [SCREEN_WIDTH // 2 - text_font.get_width() //2, SCREEN_HEIGHT // 2 - text_font.get_height() // 2])
            pygame.display.flip()

        #### Draw changes the screen ####
        pygame.display.flip()

        ##########
        # Define the refresh rate of the screen
        ##########
        clock.tick(CLOCK_TICK)


main()
