# Ryland Price
# CS1400 - MWF 8:30

import pygame


class Player:
    pass


def make_player(image_file):
    player = Player()
    player.image = pygame.image.load(image_file)
    player.width = player.image.get_width()
    player.height = player.image.get_height()
    player.center_position = [300, 500]
    player.draw_position = [player.center_position[0] - player.width // 2, player.center_position[1] - player.height]
    player.radius = player.width // 2

    return player


def move_player(player, move):
    key = pygame.key.get_pressed()

    if key[pygame.K_UP]:
        player.draw_position[1] -= move
    if key[pygame.K_DOWN]:
        player.draw_position[1] += move
    if key[pygame.K_RIGHT]:
        player.draw_position[0] += move
    if key[pygame.K_LEFT]:
        player.draw_position[0] -= move

    if player.draw_position[0] < 0:
        player.draw_position[0] = 0
    if player.draw_position[0] + player.width > 600:
        player.draw_position[0] = 600 - player.width
    if player.draw_position[1] < 0:
        player.draw_position[1] = 0
    if player.draw_position[1] + player.height > 600:
        player.draw_position[1] = 600 - player.height

    player.center_position[0] = player.draw_position[0] + player.width // 2
    player.center_position[1] = player.draw_position[1] + player.height // 2



