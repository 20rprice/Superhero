# Ryland Price
# CS1400 - MWF 8:30

import pygame


class Enemy:
    pass


def make_enemy(image_file):
    enemy = Enemy()
    enemy.image = pygame.image.load(image_file)
    enemy.width = enemy.image.get_width()
    enemy.height = enemy.image.get_height()
    enemy.center_position = [300, 300]
    enemy.draw_position = [enemy.center_position[0] - enemy.width // 2, enemy.center_position[1] - enemy.height]
    enemy.radius = enemy.width // 2

    return enemy


def move_enemy(enemy, move):
    if enemy.draw_position[0] <= 0:
        move[0] *= -1
    if enemy.draw_position[1] <= 0:
        move[1] *= -1
    if enemy.center_position[0] + enemy.radius >= 600:
        move[0] *= -1
    if enemy.center_position[1] + enemy.height // 2 >= 600:
        move[1] *= -1

    enemy.draw_position[0] += move[0]
    enemy.draw_position[1] += move[1]

    enemy.center_position[0] = enemy.draw_position[0] + enemy.width // 2
    enemy.center_position[1] = enemy.draw_position[1] + enemy.height // 2